---
name: Friend Hassu
colors:
  surface: '#111319'
  surface-dim: '#111319'
  surface-bright: '#373940'
  surface-container-lowest: '#0c0e14'
  surface-container-low: '#191b22'
  surface-container: '#1e1f26'
  surface-container-high: '#282a30'
  surface-container-highest: '#33343b'
  on-surface: '#e2e2eb'
  on-surface-variant: '#e2bdc6'
  inverse-surface: '#e2e2eb'
  inverse-on-surface: '#2e3037'
  outline: '#a98891'
  outline-variant: '#5a4047'
  surface-tint: '#ffb1c8'
  primary: '#ffb1c8'
  on-primary: '#650032'
  primary-container: '#ff4895'
  on-primary-container: '#58002c'
  inverse-primary: '#b90062'
  secondary: '#d0bcff'
  on-secondary: '#3c0091'
  secondary-container: '#571bc1'
  on-secondary-container: '#c4abff'
  tertiary: '#27e0a9'
  on-tertiary: '#003827'
  tertiary-container: '#00a47a'
  on-tertiary-container: '#003122'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffd9e2'
  primary-fixed-dim: '#ffb1c8'
  on-primary-fixed: '#3e001d'
  on-primary-fixed-variant: '#8e004a'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#54fdc4'
  tertiary-fixed-dim: '#27e0a9'
  on-tertiary-fixed: '#002116'
  on-tertiary-fixed-variant: '#00513b'
  background: '#111319'
  on-background: '#e2e2eb'
  surface-variant: '#33343b'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.025em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-xxs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  gutter-mobile: 1rem
  gutter-tablet: 1.5rem
  margin-mobile: 1rem
  margin-tablet: 2rem
---

## Brand & Style

This design system delivers a high-voltage, social-first experience that merges the electrifying saturation of contemporary Gen-Z aesthetics with refined mobile ergonomics. Inspired by striking pop-magenta backdrops, studio contrast, and tactile fluid UI, it is engineered for digital native connections, spontaneous interactions, and creator discovery.

### Brand Personality & Emotional Voice
- **Electric & Unapologetic:** Anchored by high-chroma magenta and neon violet, creating an instant burst of joy, vitality, and creative confidence.
- **Approachable & Welcoming:** Soft geometries, tactile frosted glass surfaces, and friendly curved typography ensure the interface remains light-hearted and social rather than sterile.
- **Fluid & Instantaneous:** Prioritizes real-time social presence, kinetic feedback, instant state badges, and seamless micro-gestures.

### Visual Style
A hybrid of **Glassmorphism** and **High-Contrast Modernism**. Rich layered translucencies, subtle border glows, and vibrant magenta drop blurs balance against deep cosmic slate surfaces, guaranteeing that user photos, avatars, and multimedia content stand out with maximum pop.

## Colors

The palette leverages high-energy fluorescent accents against a multi-layered dark slate foundation, maximizing visual impact and battery efficiency for prolonged mobile social engagement.

### Core Roles & Palette Strategy
- **Primary (`#F02885` - Neon Magenta):** The defining signature hue. Drives primary calls-to-action, active bottom-navigation states, live indicators, and highlight pills.
- **Secondary (`#8B5CF6` - Electric Violet):** Secondary interactions, creator badges, gradient meshes, and dynamic multi-user audio/video room highlights.
- **Tertiary (`#06D6A0` - Radiant Emerald):** Real-time positive statuses, "Active Now" online beacons, verified tags, and success toasts.
- **Neutral Foundation (`#0F1117` - Cosmic Slate):** The deep root canvas. Elevates into layered containers (`#1A1D27` and `#242836`), providing rich tactile depth without resorting to pure flat black.

### Functional Status Indicators
- **Online:** `#06D6A0` with a 4px soft radial pulse glow (`rgba(6, 214, 160, 0.4)`).
- **Away / Idle:** `#F59E0B` (Amber gold).
- **Offline / Ghost:** `#64748B` (Muted slate ring).
- **Do Not Disturb / In-Call:** `#EF4444` (Coral red).

## Typography

**Plus Jakarta Sans** provides a geometric, approachable, and punchy cadence across all digital touchpoints. Its wide apertures, friendly rounded letterforms, and tight display kerning deliver an instantly engaging social demeanor.

### Hierarchy & Treatment
- **Display & Headings:** Rendered in bold or extra-bold weights (`700` and `800`) with slight negative letter tracking (`-0.02em` to `-0.03em`) to create snappy editorial personality on profile intros and discovery headers.
- **Body:** Kept balanced at regular (`400`) and medium (`500`) weights for rapid readability in group chats, direct messages, and comment threads.
- **Labels & Microcopy:** Rendered with elevated tracking (`0.02em` to `0.04em`) and semi-bold/bold weights to guarantee instant legibility on badges, timestamps, live counts, and status pills.

## Layout & Spacing

The layout is built on a mobile-centric **4px / 8px fluid grid** with ergonomic thumb-zone positioning for rapid one-handed navigation.

### Structural Flow
- **Mobile Handheld (360px - 599px):** 4-column dynamic grid. Outer screen padding is fixed to `16px` (`space-md`), ensuring tap safety on curved displays and bezel edges. Bottom navigation and main action triggers reside in the bottom 30% thumb radius.
- **Tablet / Large Foldables (600px - 1024px):** 8-column layout with split-pane navigation (conversations list left, active thread/profile right) using a `24px` gutter.
- **Spacing Rhythm:** Micro elements (avatars, presence dots, inline icons) use `4px` to `8px` steps. Content blocks, social cards, and message clusters sit within `12px` to `16px` gaps, while primary view modules separate at `24px` to `32px`.

## Elevation & Depth

Visual hierarchy uses a refined combination of **frosted glassmorphism** and **ambient neon under-glows**, avoiding muddy black drops in favor of atmospheric depth.

### Elevation Architecture
- **Surface Level 0 (Base Canvas):** `#0F1117` — Deep matte slate void.
- **Surface Level 1 (Feed & List Cards):** Background `rgba(26, 29, 39, 0.75)` with `16px` backdrop-filter blur and a hairline outer stroke of `rgba(255, 255, 255, 0.08)`.
- **Surface Level 2 (Floating Sheets & Modals):** Background `rgba(36, 40, 54, 0.85)` with `24px` backdrop-filter blur, anchored by a diffused ambient shadow: `0 12px 36px -4px rgba(0, 0, 0, 0.5)`.
- **Surface Level 3 (Primary CTAs & Glow Triggers):** Buttons and active pills utilize a tinted neon shadow: `0 8px 24px -2px rgba(240, 40, 133, 0.45)`.
- **Border Glass Filaments:** Elevated cards and interactive chips carry a 1px border gradient transitioning from `rgba(255, 255, 255, 0.18)` at the top light-source edge to `rgba(255, 255, 255, 0.02)` at the bottom edge.

## Shapes

The design system adopts a **Rounded** shape model (`roundedness: 2`), projecting youthfulness and tactility while maintaining structural containment.

### Shape Language Rules
- **Base Components:** Standard buttons, text inputs, message bubbles, and compact list items feature `0.5rem` (`8px`) to `0.75rem` (`12px`) corner radii.
- **Cards & Story Containers:** Profile summaries, media cards, and community sheets use `1rem` (`16px`) to `1.5rem` (`24px`) radii for a friendly silhouette.
- **Pills & Status Clusters:** Filter chips, dynamic tags, presence pills, and floating action pods utilize complete pill radiuses (`9999px`).
- **Avatars & Presence Rings:** Circular geometry (`rounded-full`) wrapped with an active offset ring spacing of `2px` to seamlessly separate avatars from presence indicators.

## Components

### Buttons & Interactive CTAs
- **Primary Action Button:** Gradient fill from `#F02885` to `#E91E63` with an active drop glow (`rgba(240, 40, 133, 0.45)`). Font: `label-lg`, white text, height 48px, fully rounded pill or `12px` radius. Active state scales down to `0.97`.
- **Secondary / Glass Button:** Semi-transparent background `rgba(255, 255, 255, 0.08)` with a 1px `rgba(255, 255, 255, 0.15)` border. Text color `#F1F5F9`.
- **Icon Action Buttons:** `44x44px` circular touch targets with subtle glass backdrop and hover/press glow.

### Cards & Feed Items
- **User Profile / Friend Hassu Card:** Glass-tinted slate surface with `16px` padding, displaying high-contrast avatar, display name, username handle in muted violet, bio snippet, and inline status badges.
- **Story Ring Cards:** Vertical rounded cards (`16px` radius) with vibrant gradient outlines (`#F02885` blending to `#8B5CF6`) signifying unread social moments.

### Presence Badges & Indicators
- **Online Pill:** Compact 10px dot or labeled micro-pill with `#06D6A0` emerald center, surrounded by a 2px dark border ring to maintain contrast when overlaying user avatars.
- **Status Badges:** Small pill badges housing an emoji icon + label (`label-sm`), styled with `rgba(255, 255, 255, 0.06)` fill and subtle border tint matching the status color.

### Chips & Filter Tags
- **Selected Chip:** Solid or high-intensity `#F02885` accent background with pure white typography.
- **Unselected Chip:** Frosted dark slate (`rgba(255, 255, 255, 0.06)`) with muted silver text (`#94A3B8`). Height 32px, pill-rounded.

### Input Fields & Search Bars
- **Chat & Search Bar:** Height 44px–48px, background `rgba(26, 29, 39, 0.9)`, border `1px solid rgba(255, 255, 255, 0.1)`. Focused state transitions the border to `#F02885` with a subtle outer glow: `0 0 0 3px rgba(240, 40, 133, 0.25)`.
- **Placeholder:** Styled in `#64748B` with matching iconography.

### Social Lists & Conversation Rows
- **List Items:** Edge-to-edge touch targets (height 68px–72px) with horizontal avatar layout, two-tier text (Headline-sm for name, Body-md for preview message), right-aligned timestamp in `label-sm`, and an unread notification counter styled in vibrant magenta.