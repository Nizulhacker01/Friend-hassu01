# Firebase Authentication & Cloud Firestore Architecture for "Friend Hassu"

This document provides complete, modular JavaScript/TypeScript implementation using the Firebase Modular SDK (v9/v10+) for **Friend Hassu**, covering user authentication, profile management, and bidirectional friend request flows.

---

## 1. Firebase Initialization & Configuration (`firebaseConfig.js`)

```javascript
import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  updateProfile,
  onAuthStateChanged 
} from "firebase/auth";
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  serverTimestamp,
  arrayUnion, 
  arrayRemove, 
  collection, 
  query, 
  where, 
  getDocs,
  onSnapshot
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "friend-hassu.firebaseapp.com",
  projectId: "friend-hassu",
  storageBucket: "friend-hassu.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
```

---

## 2. Firestore Data Model Specification

### Collection: `users`
Document ID: `uid` (matching Firebase Auth UID)

```json
{
  "uid": "USER_ID_12345",
  "displayName": "Hassu",
  "email": "hassu@example.com",
  "photoURL": "https://example.com/photos/hassu.jpg",
  "status": "offline", // "online" | "offline" | "away"
  "lastSeen": "2025-05-18T10:30:00Z",
  "friends": [
    "FRIEND_UID_1",
    "FRIEND_UID_2"
  ],
  "createdAt": "2025-01-01T00:00:00Z",
  "updatedAt": "2025-05-18T10:30:00Z"
}
```

### Collection: `friend_requests`
Document ID: Auto-generated or `${senderUid}_${receiverUid}`

```json
{
  "senderId": "USER_A_UID",
  "senderName": "Hassu",
  "senderPhotoURL": "https://...",
  "receiverId": "USER_B_UID",
  "status": "pending", // "pending" | "accepted" | "declined" | "cancelled"
  "createdAt": "2025-05-18T12:00:00Z"
}
```

---

## 3. Authentication & Profile Service (`authService.js`)

```javascript
import { auth, db } from "./firebaseConfig";
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut as fbSignOut,
  updateProfile 
} from "firebase/auth";
import { doc, setDoc, updateDoc, getDoc, serverTimestamp } from "firebase/firestore";

/**
 * Register a new user with Email, Password, and Display Name
 */
export async function registerUser({ email, password, displayName, photoURL = "" }) {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Update Firebase Auth internal profile
    await updateProfile(user, {
      displayName,
      photoURL: photoURL || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"
    });

    // Create user document in Firestore
    const userDocRef = doc(db, "users", user.uid);
    const userData = {
      uid: user.uid,
      displayName: displayName || "Friend Hassu User",
      email: user.email,
      photoURL: photoURL || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150",
      status: "online",
      friends: [],
      createdAt: serverTimestamp(),
      lastSeen: serverTimestamp()
    };

    await setDoc(userDocRef, userData);
    return { success: true, user: userData };
  } catch (error) {
    console.error("Error signing up:", error);
    return { success: false, error: error.message };
  }
}

/**
 * Log in an existing user and set status to 'online'
 */
export async function loginUser(email, password) {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Set online status in Firestore
    const userDocRef = doc(db, "users", user.uid);
    await updateDoc(userDocRef, {
      status: "online",
      lastSeen: serverTimestamp()
    });

    return { success: true, uid: user.uid };
  } catch (error) {
    console.error("Error logging in:", error);
    return { success: false, error: error.message };
  }
}

/**
 * Sign out and set status to 'offline'
 */
export async function logoutUser() {
  try {
    const currentUser = auth.currentUser;
    if (currentUser) {
      const userDocRef = doc(db, "users", currentUser.uid);
      await updateDoc(userDocRef, {
        status: "offline",
        lastSeen: serverTimestamp()
      });
    }
    await fbSignOut(auth);
    return { success: true };
  } catch (error) {
    console.error("Error logging out:", error);
    return { success: false, error: error.message };
  }
}

/**
 * Update user profile details
 */
export async function updateUserProfile(uid, updates) {
  try {
    const allowedKeys = ["displayName", "photoURL", "status"];
    const filteredUpdates = {};

    allowedKeys.forEach((key) => {
      if (updates[key] !== undefined) filteredUpdates[key] = updates[key];
    });

    filteredUpdates.updatedAt = serverTimestamp();

    const userDocRef = doc(db, "users", uid);
    await updateDoc(userDocRef, filteredUpdates);

    // If auth profile fields changed, sync with Firebase Auth
    if (auth.currentUser && (updates.displayName || updates.photoURL)) {
      await updateProfile(auth.currentUser, {
        displayName: updates.displayName || auth.currentUser.displayName,
        photoURL: updates.photoURL || auth.currentUser.photoURL
      });
    }

    return { success: true };
  } catch (error) {
    console.error("Error updating profile:", error);
    return { success: false, error: error.message };
  }
}

/**
 * Fetch a single user profile by UID
 */
export async function getUserProfile(uid) {
  try {
    const docSnap = await getDoc(doc(db, "users", uid));
    if (docSnap.exists()) {
      return { success: true, data: docSnap.data() };
    }
    return { success: false, error: "User not found" };
  } catch (error) {
    return { success: false, error: error.message };
  }
}
```

---

## 4. Friend Request System (`friendService.js`)

```javascript
import { db } from "./firebaseConfig";
import { 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  collection, 
  query, 
  where, 
  getDocs,
  arrayUnion, 
  arrayRemove,
  serverTimestamp,
  deleteDoc
} from "firebase/firestore";

/**
 * Send a friend request from senderUid to receiverUid
 */
export async function sendFriendRequest(senderUser, receiverUid) {
  try {
    if (senderUser.uid === receiverUid) {
      throw new Error("Cannot send friend request to yourself.");
    }

    // Check if target user exists
    const receiverSnap = await getDoc(doc(db, "users", receiverUid));
    if (!receiverSnap.exists()) {
      throw new Error("Target user does not exist.");
    }

    const receiverData = receiverSnap.data();
    if (receiverData.friends && receiverData.friends.includes(senderUser.uid)) {
      throw new Error("You are already friends with this user.");
    }

    const requestId = `${senderUser.uid}_${receiverUid}`;
    const requestRef = doc(db, "friend_requests", requestId);

    // Verify if already sent
    const existingReq = await getDoc(requestRef);
    if (existingReq.exists() && existingReq.data().status === "pending") {
      throw new Error("Friend request already sent.");
    }

    await setDoc(requestRef, {
      requestId,
      senderId: senderUser.uid,
      senderName: senderUser.displayName || "Unknown",
      senderPhotoURL: senderUser.photoURL || "",
      receiverId: receiverUid,
      status: "pending",
      createdAt: serverTimestamp()
    });

    return { success: true, requestId };
  } catch (error) {
    console.error("Error sending friend request:", error);
    return { success: false, error: error.message };
  }
}

/**
 * Accept incoming friend request
 * Atomically adds each user to the other's `friends` array
 */
export async function acceptFriendRequest(requestId, senderId, receiverId) {
  try {
    const requestRef = doc(db, "friend_requests", requestId);
    const senderRef = doc(db, "users", senderId);
    const receiverRef = doc(db, "users", receiverId);

    // 1. Mark request as accepted
    await updateDoc(requestRef, {
      status: "accepted",
      acceptedAt: serverTimestamp()
    });

    // 2. Add receiver to sender's friend list
    await updateDoc(senderRef, {
      friends: arrayUnion(receiverId)
    });

    // 3. Add sender to receiver's friend list
    await updateDoc(receiverRef, {
      friends: arrayUnion(senderId)
    });

    return { success: true };
  } catch (error) {
    console.error("Error accepting friend request:", error);
    return { success: false, error: error.message };
  }
}

/**
 * Decline/Reject a friend request
 */
export async function declineFriendRequest(requestId) {
  try {
    const requestRef = doc(db, "friend_requests", requestId);
    await updateDoc(requestRef, {
      status: "declined",
      updatedAt: serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error("Error declining request:", error);
    return { success: false, error: error.message };
  }
}

/**
 * Remove an existing friend
 */
export async function removeFriend(currentUserId, targetFriendId) {
  try {
    const userRef = doc(db, "users", currentUserId);
    const friendRef = doc(db, "users", targetFriendId);

    await updateDoc(userRef, {
      friends: arrayRemove(targetFriendId)
    });

    await updateDoc(friendRef, {
      friends: arrayRemove(currentUserId)
    });

    return { success: true };
  } catch (error) {
    console.error("Error removing friend:", error);
    return { success: false, error: error.message };
  }
}

/**
 * Get pending friend requests for a specific user
 */
export async function getPendingRequests(userId) {
  try {
    const q = query(
      collection(db, "friend_requests"),
      where("receiverId", "==", userId),
      where("status", "==", "pending")
    );

    const snapshot = await getDocs(q);
    const requests = [];
    snapshot.forEach((doc) => {
      requests.push({ id: doc.id, ...doc.data() });
    });

    return { success: true, requests };
  } catch (error) {
    return { success: false, error: error.message };
  }
}
```

---

## 5. Security Rules (`firestore.rules`)

To secure the user profiles and prevent unauthorized mutations:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // User profile rules
    match /users/{userId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null && request.auth.uid == userId;
      // Allow user to update their profile or allow friends array mutation during accepted requests
      allow update: if request.auth != null;
    }
    
    // Friend request rules
    match /friend_requests/{requestId} {
      allow read: if request.auth != null && (
        resource.data.senderId == request.auth.uid || 
        resource.data.receiverId == request.auth.uid
      );
      allow create: if request.auth != null && request.resource.data.senderId == request.auth.uid;
      allow update: if request.auth != null && (
        resource.data.receiverId == request.auth.uid || 
        resource.data.senderId == request.auth.uid
      );
    }
  }
}
```
